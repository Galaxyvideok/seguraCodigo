/*1. Qual cidade possui o maior número de vizinhos? Informar cidade e quantidade de vizinhos. 

2. Qual cidade possui o menor número de vizinhos? Informar cidade e quantidade de vizinhos.

3. Qual cidade possui o vizinho mais distante? Informar cidade, vizinho e distancia.

4. Qual cidade possui o vizinho mais próximo? Informar cidade, vizinho e distância.

5. Dado os nomes de duas cidades pertencentes a matriz de adjacência, qual a distância entre elas?*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define INICIO "--------INICIO--------"
#define RESULTADO "-----------RESULTADO-----------"
#define CORTE "-------------------------------------"
#define MAX 13

FILE * abrirArquivo(char * nomeArq, char * modo) {
    FILE * arq;
    arq = fopen( nomeArq, modo );
    if ( arq == NULL) {
        printf("ERRO ao abrir o arquivo.");
        exit(-1);
    }
    return arq;
}

void carregarArquivo1(FILE *arquivo, int *guarda) {
    char lixo;
    fscanf(arquivo, "%d", guarda);
    fscanf(arquivo, " %c", &lixo);
}

void carregarArquivo2(FILE *arquivo, int quanti, char resposta[][MAX]) {
    int i;
    char lixo;
    int guarda;
    for (i = 0; i < quanti; i++){
        fscanf(arquivo, "%d", &guarda);
        fscanf(arquivo, " %c", &lixo); 
        fscanf(arquivo, "%12s", resposta[i]); 
    }
}

void carregarArquivo3(FILE *arquivo, int quanti, float resposta[][MAX]) {
    int i, j;
    char lixo;
    fscanf(arquivo, "%c", &lixo);
    for (i = 0; i < quanti; i++){
        for (j = 0; j < quanti; j++){
            fscanf(arquivo, "%f", &resposta[i][j]);
            fscanf(arquivo, "%c", &lixo); 
        }
        
    }
}


void listar(char vet[][MAX], int quanti){
    int i, j;
    for (i = 0; i < quanti; i++){
        for (j = 0; j < MAX-1; j++){
            printf("%c",vet[i][j]);
        }
        printf("\n");
    }
    
}

void listar2(float vet[][MAX], int quanti){
    int i, j;
    for (i = 0; i < quanti; i++){
        for (j = 0; j < quanti; j++){
            printf("%6.2f | ",vet[i][j]);
        }
        printf("\n");
    }
}

int pesquisarMatriz(float matriz[][30], int quanti, float pesq){
    int i, j;
    for (i = 0; i < quanti; i++){
        for (j = 0; j < quanti; j++){
            if (matriz[i][j] == pesq){
                return i;
            }
        }
    }
    return -1;
}

void defineVizinhos(float cidades[][30],int quanti, int desci, char listagemNomes[][MAX]){
    float vetCont[30] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    int i,j, maior = 0, menor = 999;
    for (i = 0; i < quanti; i++){
        for (j = 0; j < quanti; j++){
            if (cidades[i][j] > 0){
                vetCont[i]++;
            }
        }
    }
    if (desci == 0){
        for ( i = 0; i < 30; i++){
            if (vetCont[i] > maior){
                maior = i;
            }
        }
        printf("A cidade que tem mais vizinhos e : %s \n", listagemNomes[maior]);
        printf("Essa cidade possui: %2.2f vizinhos \n", vetCont[maior]);
    }else{
        for (i = 0; i < 30; i++){
            if (vetCont[i] < menor){
                menor = i;
            }
        }
        printf("A cidade que tem mais vizinhos e : %s \n", listagemNomes[menor]);
        printf("Essa cidade possui: %2.2f vizinhos \n", vetCont[menor]);
    }
}

void vizinhoDistancia(float cidades[][30],int quanti, int desci, char listagemNomes[][MAX]){
    int i,j;
    int guardaIndice1,guardaIndice2;
    int vizinho;
    float maior = 0;
    float menor = 999;
    if (desci == 0){
        for (i = 0; i < quanti; i++){
            for (j = 0; j < quanti; j++){
                if (cidades[i][j] > maior){
                    maior = cidades[i][j];
                    guardaIndice1 = i;
                    guardaIndice2 = j;
                }
            }
        }
        vizinho = pesquisarMatriz(cidades,quanti,maior);
        printf("A cidade que tem o vizinho mais distante e: %s\n",listagemNomes[guardaIndice1]);
        printf("O vizinho: %s\n",listagemNomes[vizinho]);
        printf("A distancia: %3.2f\n", maior);
    }else{
        for (i = 0; i < quanti; i++){
            for (j = 0; j < quanti; j++){
                if (cidades[i][j] < menor){
                    menor = cidades[i][j];
                    guardaIndice1 = i;
                    guardaIndice2 = j;
                }
            }
        }
        vizinho = pesquisarMatriz(cidades,quanti,menor);
        printf("A cidade que tem o vizinho mais proximo e: %s\n",listagemNomes[guardaIndice1]);
        printf("O vizinho: %s\n",listagemNomes[vizinho]);
        printf("A distancia: %3.2f\n", menor);
    }
}

void calculoDistanciaCidades(float cidades[][30],int quanti, char listagemNomes[][MAX]){
    char nomeCity1[MAX];
    char nomeCity2[MAX];
    int i, j;
    float distancia;
    printf("Digite o nome da primeira cidade:");
    scanf(" %12[^\n]s", nomeCity1);
    printf("Digite o nome da segunda cidade cidade:");
    scanf(" %12[^\n]s", nomeCity2);
    for (i = 0; i < quanti; i++){
        for (j = 0; j < quanti; j++){
            if ((strcmp(listagemNomes[i],nomeCity1) == 0)&&(strcmp(listagemNomes[j],nomeCity2) == 0)){
                distancia = cidades[i][j];
            }
        }
    }
    printf("A distancia entre as cidades %s e %s sera: %3.2f\n", nomeCity1, nomeCity2, distancia);
}

int menu() {
    int op;
    printf("\n\nMENU CIDADES\n\n");
    printf("1 - Maior número de vizinhos\n");
    printf("2 - Menor número de vizinhos\n");
    printf("3 - Vizinho mais distante\n");
    printf("4 - Vizinho mais próximo\n");
    printf("5 - Distância entre duas cidades\n");
    printf("0 - Sair\n");
    do {
        printf("Escolha sua opção: ");
        scanf(" %d", &op);
    } while (op < 0 || op > 5);
    return op;
}

int main() {
    FILE * arquivo;
    arquivo = abrirArquivo("../arquivo/arq.txt", "r");
    int quantiCity;
    int op;
    carregarArquivo1(arquivo, &quantiCity);
    char listagemNomes[quantiCity][MAX];
    carregarArquivo2(arquivo, quantiCity, listagemNomes);
    float cidades[quantiCity][quantiCity];
    carregarArquivo3(arquivo, quantiCity, cidades);
    listar(listagemNomes,quantiCity);
    listar2(cidades,quantiCity);
    do{
        op = menu();
        switch (op) {
            case 1:
                defineVizinhos(cidades,quantiCity,0,listagemNomes);
                break;
            case 2:
                defineVizinhos(cidades,quantiCity,1,listagemNomes);
                break;
            case 3:
                vizinhoDistancia(cidades,quantiCity,0,listagemNomes);
                break;
            case 4:
                vizinhoDistancia(cidades,quantiCity,1,listagemNomes);
                break;
            case 5:
                calculoDistanciaCidades(cidades,quantiCity,listagemNomes);
                break;
            case 0:
                break;
            default:
                printf("Opção inválida. Tente novamente.\n");
        }
    } while (op != 0);
	return 0;
}